﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class ReplayState
    {
    }
}
