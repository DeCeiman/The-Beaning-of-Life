﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class MainMenuState : GameObjectList
    {
        private GameObjectList menuButtons = new GameObjectList();
        private GameObjectList mainMenuBeanLegend = new GameObjectList();
        private GameObjectList mainMenuBlockLegend = new GameObjectList();
        private SpriteGameObject beanLegendDesc, blockLegendDesc;
        private float beanIconPosY;
        private SpriteGameObject background;
        private SpriteGameObject gameTitle;
        private SpriteGameObject selectArrow, mouseCursor;
        private int arrowOffset;
        public int buttonSelected;
        private int startButtonYPos, creditsButtonYPos, quitButtonYPos, settingsButtonXPos, settingsButtonYPos, practiceButtonYPos, leaderBoardButtonYPos;
        public bool buttonIsPressed, clicked;

        public MainMenuState() : base()
        {
            beanIconPosY = 250;
            buttonSelected = 1;
            Reset();
            selectArrow.Origin = selectArrow.Center;
            mouseCursor.Origin = mouseCursor.Center;
            beanLegendDesc.position = new Vector2(20, 230);
            blockLegendDesc.position = new Vector2(720, 200);
        }

        public override void Reset()
        {
            base.Reset();
            arrowOffset = 100;
            startButtonYPos = 250;
            quitButtonYPos = 650;
            creditsButtonYPos = 550;
            leaderBoardButtonYPos = 450;
            practiceButtonYPos = 350;
            settingsButtonXPos = 125;
            settingsButtonYPos = 50;
            
            background = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background.position = new Vector2(0, 0);
            this.Add(background);

            gameTitle = new SpriteGameObject("Sprites/Hud/title");
            gameTitle.position = new Vector2(120, 50);
            this.Add(gameTitle);

            selectArrow = new SpriteGameObject("Sprites/Hud/select_arrow");
            this.Add(selectArrow);

            menuButtons.Add(new StartButton(GameEnvironment.Screen.X / 2, startButtonYPos));
            menuButtons.Add(new QuitButton(GameEnvironment.Screen.X / 2, quitButtonYPos));
            menuButtons.Add(new CreditsButton(GameEnvironment.Screen.X / 2, creditsButtonYPos));
            menuButtons.Add(new LeaderBoardButton(GameEnvironment.Screen.X / 2, leaderBoardButtonYPos));
            menuButtons.Add(new PracticeButton(GameEnvironment.Screen.X / 2, practiceButtonYPos));
            menuButtons.Add(new SettingsButton(settingsButtonXPos, settingsButtonYPos));
            this.Add(menuButtons);

            mainMenuBeanLegend.Add(new SpriteGameObject("Sprites/Beans/kidney_bean"));
            mainMenuBeanLegend.Add(new SpriteGameObject("Sprites/Beans/brown_bean"));
            mainMenuBeanLegend.Add(new SpriteGameObject("Sprites/Beans/white_bean"));
            mainMenuBeanLegend.Add(new SpriteGameObject("Sprites/Beans/coffee_bean"));
            this.Add(mainMenuBeanLegend);

            mainMenuBlockLegend.Add(new SpriteGameObject("Sprites/PNGGrass/slice03_03"));
            mainMenuBlockLegend.Add(new SpriteGameObject("Sprites/PNGMetal/frozen_metal"));
            mainMenuBlockLegend.Add(new SpriteGameObject("Sprites/PNGTundra/slice03_03"));
            mainMenuBlockLegend.Add(new SpriteGameObject("Sprites/PNGSand/slice03_03"));
            this.Add(mainMenuBlockLegend);

            beanLegendDesc = new SpriteGameObject("Sprites/Hud/bean_legend_desc");
            this.Add(beanLegendDesc);

            blockLegendDesc = new SpriteGameObject("Sprites/Hud/block_legend_desc");
            this.Add(blockLegendDesc);

            
            for (int iBean = 0; iBean < 4; iBean++)
            {
                mainMenuBeanLegend.Children[iBean].Position = new Vector2(100, beanIconPosY + (iBean * 100));
            }

            for (int iBlock = 0; iBlock < 4; iBlock++)
            {
                mainMenuBlockLegend.Children[iBlock].Position = new Vector2(1150, beanIconPosY + (iBlock * 100));
            }

            mouseCursor = new SpriteGameObject("Sprites/Hud/cursor");
            this.Add(mouseCursor);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
           
            selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
            if (buttonSelected == 0) selectArrow.position = new Vector2(-1000, 0);
            
            if (buttonSelected == 1)
            {
                selectArrow.position.Y = startButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed)
                {
                    GameEnvironment.GameStateManager.SwitchTo("SkinSelectState");
                }
            }

            if(buttonSelected == 2)
            {
                selectArrow.position.Y = practiceButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed)
                {
                    GameEnvironment.GameStateManager.SwitchTo("PracticeState");
                }
            }
            
            if (buttonSelected == 5)
            {
                selectArrow.position.Y = quitButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed) Program.Quit();
            }

            if (buttonSelected == 3)
            {
                selectArrow.position.Y = leaderBoardButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed)
                {
                    GameEnvironment.GameStateManager.SwitchTo("LeaderBoardState");
                }
            }

            if (buttonSelected == 4)
            {
                selectArrow.position.Y = creditsButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed)
                {
                    GameEnvironment.GameStateManager.SwitchTo("CreditState");
                }
            }

            if (buttonSelected == 6)
            {
                selectArrow.position.Y = settingsButtonYPos;
                selectArrow.position.X = settingsButtonXPos + arrowOffset;
                if (buttonIsPressed)
                {
                    GameEnvironment.GameStateManager.SwitchTo("SettingsState");
                }
            }

            foreach (Button button in menuButtons.Children)
            {
                if (button is StartButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked)
                    {
                        GameEnvironment.GameStateManager.SwitchTo("SkinSelectState");
                    }
                }

                if (button is QuitButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) Program.Quit();
                }

                if (button is LeaderBoardButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked)
                    {
                        GameEnvironment.GameStateManager.SwitchTo("LeaderBoardState");
                    }
                }

                if (button is PracticeButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked)
                    {
                        GameEnvironment.GameStateManager.SwitchTo("PracticeState");
                    }
                }

                if (button is CreditsButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked)
                    {
                        GameEnvironment.GameStateManager.SwitchTo("CreditState");
                    }
                }

                if (button is SettingsButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked)
                    {
                        GameEnvironment.GameStateManager.SwitchTo("SettingsState");
                    }
                }
            }
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            mainMenuBeanLegend.Draw(gameTime,spriteBatch);
        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (buttonSelected <= 0) buttonSelected = 6;
            if (buttonSelected >= 7) buttonSelected = 1;

            if (inputHelper.KeyPressed(Keys.Up)) buttonSelected -= 1;
            if (inputHelper.KeyPressed(Keys.Down)) buttonSelected += 1;
            if (inputHelper.KeyPressed(Keys.Enter)) buttonIsPressed = true;
            else buttonIsPressed = false;

            if (inputHelper.MouseLeftButtonPressed()) clicked = true;
            else clicked = false;
            mouseCursor.position = inputHelper.MousePosition;
        }
    }
}