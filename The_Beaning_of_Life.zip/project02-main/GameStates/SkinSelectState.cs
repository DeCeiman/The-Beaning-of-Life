﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace BaseProject
{
    class SkinSelectState : GameObjectList
    { 
      private GameObjectList menuButtons = new GameObjectList();
      private SpriteGameObject background;
      private SpriteGameObject character;
      private SpriteGameObject selectArrow, mouseCursor;
      private Player thePlayer;
      private int arrowOffset;
      public int buttonSelected;
      private int returnButtonY, returnButtonX, selectButtonY, leftButtonX, leftButtonY, rightButtonX, rightButtonY;
      public bool buttonIsPressed, clicked;
      //public int skinNumber;
      //public static int skinColor;

      public SkinSelectState() : base()
    {

        Reset();
        selectArrow.Origin = selectArrow.Center;
        mouseCursor.Origin = mouseCursor.Center;
        }

       public override void Reset()
       {
        base.Reset();
        arrowOffset = 100;
        returnButtonX = 50;
        returnButtonY = 50;
        selectButtonY = 550;
        leftButtonY = 450;
        leftButtonX = GameEnvironment.Screen.X / 2 - 100;
        rightButtonX = GameEnvironment.Screen.X / 2 + 100;
        rightButtonY = 450;
        //skinColor = 4;

        background = new SpriteGameObject("Sprites/Backgrounds/background_test");
        background.position = new Vector2(0, 0);
        this.Add(background);

        character = new SpriteGameObject("Sprites/Yellow/alien_yellow");
        character.position = new Vector2(GameEnvironment.Screen.X / 2, 300);
        this.Add(character);

        //thePlayer = new Player(new Vector2(GameEnvironment.Screen.X / 2, 300), skinColor);
        //this.Add(thePlayer);

        selectArrow = new SpriteGameObject("Sprites/Hud/select_arrow");
        this.Add(selectArrow);

        menuButtons.Add(new ReturnButton(returnButtonX, returnButtonY));
        menuButtons.Add(new LeftButton(leftButtonX, leftButtonY));
        menuButtons.Add(new SelectButton(GameEnvironment.Screen.X / 2, selectButtonY));
        menuButtons.Add(new RightButton(rightButtonX, rightButtonY));
        this.Add(menuButtons);

        mouseCursor = new SpriteGameObject("Sprites/Hud/cursor");
        this.Add(mouseCursor);
       }
       public override void Update(GameTime gameTime)
       {
        base.Update(gameTime);
        selectArrow.position.X = returnButtonX + arrowOffset;
        if (buttonSelected == 0) selectArrow.position = new Vector2(-1000, 0);

        if (buttonSelected == 1)
        {
            selectArrow.position.Y = returnButtonY;
            selectArrow.position.X = returnButtonX + arrowOffset;
            if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
        }
        if (buttonSelected == 2) //left button
        {
            selectArrow.position.Y = leftButtonY;
            selectArrow.position.X = leftButtonX;
                if (buttonIsPressed) ; //skinColor -= 1; ;
                //if (skinColor <= 0) skinColor = 7;
            }
        if (buttonSelected == 3) //select button
        {
            selectArrow.position.Y = selectButtonY;
            selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
            if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("PlayingState");
        }
        if (buttonSelected == 4) //right button
        {
            selectArrow.position.Y = rightButtonY;
            selectArrow.position.X = rightButtonX;
                if (buttonIsPressed) ; //skinColor += 1;
                //if (skinColor >= 7) skinColor = 0;
        }

        foreach (Button button in menuButtons.Children)
        {
            if (button is ReturnButton)
                {
                if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
                }
            if (button is LeftButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) ; //skinColor -= 1;
                }
            if (button is SelectButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("PlayingState");
                }
            if (button is RightButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) ; //skinColor += 2;
                }

                /*if (skinColor == 0) thePlayer.playerColor = 0;
                if (skinColor == 1) thePlayer.playerColor = 1;
                if (skinColor == 2) thePlayer.playerColor = 2;
                if (skinColor == 3) thePlayer.playerColor = 3;
                if (skinColor == 4) thePlayer.playerColor = 4;
                if (skinColor == 5) thePlayer.playerColor = 5;
                if (skinColor == 6) thePlayer.playerColor = 6;
                if (skinColor == 7) thePlayer.playerColor = 7; */
            }
       }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (inputHelper.KeyPressed(Keys.Up)) buttonSelected = 1;
        if (inputHelper.KeyPressed(Keys.Down)) buttonSelected = 2;
        if (inputHelper.KeyPressed(Keys.Down) && buttonSelected == 2) buttonSelected = 3;
        if (inputHelper.KeyPressed(Keys.Down) && buttonSelected == 3) buttonSelected = 4;
        if (inputHelper.KeyPressed(Keys.Enter)) buttonIsPressed = true;
        else buttonIsPressed = false;

        if (inputHelper.MouseLeftButtonPressed()) clicked = true;
        else clicked = false;
        mouseCursor.position = inputHelper.MousePosition;
    }
  }
}

