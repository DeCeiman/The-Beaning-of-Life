﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class CreditState : GameObjectList
    {
        private GameObjectList menuButtons = new GameObjectList();
        private SpriteGameObject background;
        private SpriteGameObject gameTitle;
        private SpriteGameObject selectArrow, mouseCursor;
        private TextGameObject developedBy;
        private TextGameObject evolvedStudios;
        private TextGameObject credits1;
        private TextGameObject credits2;
        private TextGameObject inAssignmentOf;
        private TextGameObject assignmentCredit;
        private TextGameObject specialThanks;
        private TextGameObject thanksCredits;
        private TextGameObject musicBy;
        private TextGameObject musicCredits;
        private TextGameObject spritesBy;
        private TextGameObject spriteCredits;
        private int arrowOffset;
        public int buttonSelected;
        private int returnButtonY;
        public bool buttonIsPressed, clicked;

        public CreditState() : base()
        {
            Reset();

            selectArrow.Origin = selectArrow.Center;
            mouseCursor.Origin = mouseCursor.Center;

            developedBy.position = new Vector2(400, 100);
            evolvedStudios.position = new Vector2(875, 100);
            credits1.position = new Vector2(400, 150);
            credits2.position = new Vector2(400, 200);
            inAssignmentOf.position = new Vector2(400, 275);
            assignmentCredit.position = new Vector2(1000, 275);
            specialThanks.position = new Vector2(400, 350);
            thanksCredits.position = new Vector2(400, 400);
            musicBy.position = new Vector2(400, 475);
            musicCredits.position = new Vector2(400, 525);
            spritesBy.position = new Vector2(400, 600);
            spriteCredits.position = new Vector2(650, 600);

            developedBy.Text = "This game has been developed by:";
            evolvedStudios.Text = "Evolved Studios LMTD";
            credits1.Text = "Amirali Eslami Hassanabadi, Bora Oskal, Ciaran Nijman";
            credits2.Text =  "Daniel Antonian, Finn Hoogerwerf and Jeffrey Huisman.";
            inAssignmentOf.Text = "This game has been made in assignment of:";
            assignmentCredit.Text = "HvA and Arch.";
            specialThanks.Text = "Special thanks to:";
            thanksCredits.Text = "Bas Pijls, Dolinde van Beek, Mike Hofstede and Lincy Ellermeijer.";
            musicBy.Text = "Music used:";
            musicCredits.Text = "8 Bit Hideout By HeatleyBros, " +
                "Game On By HeatleyBros.";
            spritesBy.Text = "Sprites made by:";
            spriteCredits.Text = "Arch and EzraJuju.";
        }

        public override void Reset() 
        {
            base.Reset();
            arrowOffset = 100;
            returnButtonY = 50;

            background = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background.position = new Vector2(0, 0);
            this.Add(background);

            gameTitle = new SpriteGameObject("Sprites/Hud/title");
            gameTitle.position = new Vector2(120, -50);
            this.Add(gameTitle);

            selectArrow = new SpriteGameObject("Sprites/Hud/select_arrow");
            this.Add(selectArrow);

            menuButtons.Add(new ReturnButton(125, returnButtonY));
            this.Add(menuButtons);

            mouseCursor = new SpriteGameObject("Sprites/Hud/cursor");
            this.Add(mouseCursor);

            evolvedStudios = new TextGameObject("Sprites/Font/GameFont");
            this.Add(evolvedStudios);

            developedBy = new TextGameObject("Sprites/Font/GameFont");
            this.Add(developedBy);
            
            credits1 = new TextGameObject("Sprites/Font/GameFont");
            this.Add(credits1);

            credits2 = new TextGameObject("Sprites/Font/GameFont");
            this.Add(credits2);

            inAssignmentOf = new TextGameObject("Sprites/Font/GameFont");
            this.Add(inAssignmentOf);

            assignmentCredit = new TextGameObject("Sprites/Font/GameFont");
            this.Add(assignmentCredit);

            specialThanks = new TextGameObject("Sprites/Font/GameFont");
            this.Add(specialThanks);

            thanksCredits = new TextGameObject("Sprites/Font/GameFont");
            this.Add(thanksCredits);

            musicBy = new TextGameObject("Sprites/Font/GameFont");
            this.Add(musicBy);

            musicCredits = new TextGameObject("Sprites/Font/GameFont");
            this.Add(musicCredits);

            spritesBy = new TextGameObject("Sprites/Font/GameFont");
            this.Add(spritesBy);

            spriteCredits = new TextGameObject("Sprites/Font/GameFont");
            this.Add(spriteCredits);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
            if (buttonSelected == 0) selectArrow.position = new Vector2(-1000, 0);

            if (buttonSelected == 1)
            {
                selectArrow.position.Y = returnButtonY;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
            }

            foreach (Button button in menuButtons.Children)
            {
                if (button is ReturnButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
                }
            }
        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (inputHelper.KeyPressed(Keys.Up)) buttonSelected = 1;
            if (inputHelper.KeyPressed(Keys.Enter)) buttonIsPressed = true;
            else buttonIsPressed = false;

            if (inputHelper.MouseLeftButtonPressed()) clicked = true;
            else clicked = false;
            mouseCursor.position = inputHelper.MousePosition;
        }

    }
}
