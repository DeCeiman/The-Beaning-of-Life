﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class QuitState : GameObjectList
    {
        private GameObjectList menuButtons = new GameObjectList();
        private SpriteGameObject background;
        private SpriteGameObject gameTitle;
        private SpriteGameObject selectArrow, mouseCursor;
        private TextGameObject practiceText;
        private int arrowOffset;
        public int buttonSelected;
        private int startButtonYPos, quitButtonYPos;
        public bool buttonIsPressed, clicked;

        public QuitState() : base()
        {
            Reset();
            selectArrow.Origin = selectArrow.Center;
            mouseCursor.Origin = mouseCursor.Center;
            practiceText.Text = "You quit!";
            practiceText.position = new Vector2(500, 200);
        }

        public override void Reset()
        {
            base.Reset();
            arrowOffset = 100;
            startButtonYPos = 400;
            quitButtonYPos = 550;

            background = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background.position = new Vector2(0, 0);
            this.Add(background);

            gameTitle = new SpriteGameObject("Sprites/Hud/title");
            gameTitle.position = new Vector2(120, 50);
            this.Add(gameTitle);

            practiceText = new TextGameObject("Sprites/Font/GameFont");
            this.Add(practiceText);

            selectArrow = new SpriteGameObject("Sprites/Hud/select_arrow");
            this.Add(selectArrow);

            menuButtons.Add(new RestartButton(GameEnvironment.Screen.X / 2, startButtonYPos));
            menuButtons.Add(new QuitButton(GameEnvironment.Screen.X / 2, quitButtonYPos));
            this.Add(menuButtons);

            mouseCursor = new SpriteGameObject("Sprites/Hud/cursor");
            this.Add(mouseCursor);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
            if (buttonSelected == 0) selectArrow.position = new Vector2(-1000, 0);

            if (buttonSelected == 1)
            {
                selectArrow.position.Y = startButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("PracticeState");
            }

            if (buttonSelected == 2)
            {
                selectArrow.position.Y = quitButtonYPos;
                selectArrow.position.X = GameEnvironment.Screen.X / 2 + arrowOffset;
                if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
            }

            foreach (Button button in menuButtons.Children)
            {
                if (button is RestartButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("PlayingState");
                }

                if (button is QuitButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
                }
            }
        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (inputHelper.KeyPressed(Keys.Up)) buttonSelected = 1;
            if (inputHelper.KeyPressed(Keys.Down)) buttonSelected = 2;
            if (inputHelper.KeyPressed(Keys.Enter)) buttonIsPressed = true;
            else buttonIsPressed = false;

            if (inputHelper.MouseLeftButtonPressed()) clicked = true;
            else clicked = false;
            mouseCursor.position = inputHelper.MousePosition;
        }
    }
}