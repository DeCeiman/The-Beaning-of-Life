﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class LoadingState : GameObjectList
    {
        private SpriteGameObject background1;
        private SpriteGameObject background2;
        private SpriteGameObject background3;
        private TextGameObject randomTip;
        private TextGameObject loadingPercentage;
        private float percentage;
        private float randomNumber;
        private SpriteGameObject gameTitle;
        private double timeSeconds;
        public Boolean firstScreen, secondScreen, thirdScreen;


        public LoadingState() : base()
        {
            Reset();

            randomTip.position = new Vector2(250, 650);
            if (randomNumber == 0) randomTip.Text = "Try to launch yourself using the Explosive Bean explosion blast";
            if (randomNumber == 1) randomTip.Text = "Use the Cleric Bean to get useful powerups such as infinite fart";
            if (randomNumber == 2) randomTip.Text = "Try to beat the level as fast as possible to get a higher score";
            if (randomNumber == 3) randomTip.Text = "Different beans give different amounts of fart power and powerups";
            if (randomNumber == 4) randomTip.Text = "Use the tips found on the signs spread across the map while in-game";
            if (randomNumber == 5) randomTip.Text = "If you have trouble winning you can utilize the practice mode";

            loadingPercentage.position = new Vector2(50, 650);
        }

        public override void Reset()
        {
            base.Reset();

            timeSeconds = 0;
            firstScreen = true;

            percentage = -600;

            randomNumber = GameEnvironment.Random.Next(0, 6);

            background3 = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background3.position = new Vector2(0, 0);
            this.Add(background3);

            randomTip = new TextGameObject("Sprites/Font/GameFont");
            this.Add(randomTip);

            loadingPercentage = new TextGameObject("Sprites/Font/GameFont");
            this.Add(loadingPercentage);

            gameTitle = new SpriteGameObject("Sprites/Hud/title");
            gameTitle.position = new Vector2(120, 50);
            this.Add(gameTitle);

            background2 = new SpriteGameObject("Sprites/Hud/hvaandarch");
            background2.position = new Vector2(-125, -50);
            background2.Scale = 0.66666666666666666667f;
            this.Add(background2);

            background1 = new SpriteGameObject("Sprites/Hud/evolvedstudioslmtd");
            background1.position = new Vector2(-100, -50);
            background1.Scale = 0.66666666666666666667f;
            this.Add(background1);
        }

        public override void Update(GameTime gameTime)
        {
            timeSeconds += gameTime.ElapsedGameTime.TotalSeconds;

            percentage += 1;
            loadingPercentage.Text = "Loading:" + (percentage / 3) + "%";

            if ((int)timeSeconds == 5 && firstScreen == true)
            {
                firstScreen = false;
                secondScreen = true;
                this.Remove(background1);
                timeSeconds = 0;
            }

            if ((int)timeSeconds == 5 && secondScreen == true)
            {
                secondScreen = false;
                thirdScreen = true;
                this.Remove(background2);
                timeSeconds = 0;
            }

            if ((float) percentage >= 200 && thirdScreen == true)
            {
                thirdScreen = false;
                this.Remove(background3);
                timeSeconds = 0;
                GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
            }

        }
    }
}
