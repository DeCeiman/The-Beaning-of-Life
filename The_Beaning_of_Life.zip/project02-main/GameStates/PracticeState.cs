﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace BaseProject
{
    class PracticeState : GameObjectList
    {
        private GameObjectList thePlatforms = new GameObjectList();
        private GameObjectList dirtFillings = new GameObjectList();
        private GameObjectList enemyBeans = new GameObjectList();
        private GameObjectList pickupBeans = new GameObjectList();
        private Vector2 platformPosition;
        private int[] spriteUsed = { 6, 5, 4, 3, 2, 1, 0 };
        private FartMeterComplete fartMeter;
        private PracticeMap level = new PracticeMap();
        private Player thePlayer;
        private PracticeToilet theToilet;
        private TextGameObject timeText;
        public static string finalTime;
        private double timeSeconds;
        private double timeMinutes;
        private int randomNumber;
        private string randomMusicName;
        private SpriteGameObject background;
        private Icons icons = new Icons();
        private Vector2 divideScrollVelocity = new Vector2(20, 8.3f), screenshake = new Vector2(20, 20);
        private float ticks;
        private int metalAmount = 0, grassAmount = 0, sandAmount = 0;
        private bool allowPlayingGrassLandingSound, allowPlayingSandLandingSound, allowPlayingMetalLandingSound;

        public PracticeState()
        {
            // Create and Initialize game objects  
            Reset();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
                // Pass keyboard state to Global so we can use it everywhere            
                // Update the game objects
                Vector2 playerCam = GameEnvironment.Screen.ToVector2() / 2 - thePlayer.position;
                if (thePlayer.lookUp) playerCam += new Vector2(0, 500);
                if (thePlayer.lookDown) playerCam += new Vector2(0, -500);
                if (thePlayer.lookLeft) playerCam += new Vector2(500, 0);
                if (thePlayer.lookRight) playerCam += new Vector2(-500, 0);

                velocity = (playerCam - position) / 25;
                position += new Vector2(velocity.X / divideScrollVelocity.X, velocity.Y / divideScrollVelocity.Y);
                position = new Vector2(Math.Clamp(Position.X, -(PracticeMap.cols * Platform.width) + GameEnvironment.Screen.X, 0), Math.Clamp(Position.Y, -(PracticeMap.rows * Platform.height) + GameEnvironment.Screen.Y, PracticeMap.rows * Platform.height * 4));


                bool sandTemp = false;
                bool metalTemp = false;
                int amountSandNotColliding = 0;
                int amountMetalNotColliding = 0;
                int amountGrassNotColliding = 0;
                foreach (Platform platform in thePlatforms.Children)
                {
                    thePlayer.particlesCollideWith(platform);

                    if (distanceBetweenPlayerAnd(platform)) //checks if player is in 1000 pixels distance of a platform, if so it checks that block else it doesn't. this reduces lag
                    {
                        if (platform is Tundra) platform.PlatformEffect(thePlayer); //checks tundra
                    }

                    if (platform is Sand) //checks sand
                    {
                        if (distanceBetweenPlayerAnd(platform)) //checks if player is in 1000 pixels distance of a platform, if so it checks that block else it doesn't. this reduces lag
                        {
                            if (platform.TouchPlatform(thePlayer)) sandTemp = true;
                            platform.PlatformEffect(thePlayer, sandTemp);

                        }

                        if (!platform.TouchPlatform(thePlayer)) amountSandNotColliding++;
                        if (platform.TouchPlatform(thePlayer) && thePlayer.velocity.Y > 0 && allowPlayingSandLandingSound)
                        {
                            GameEnvironment.AssetManager.PlaySound("Audio/land_sand");
                            allowPlayingSandLandingSound = false;
                        }
                        if (amountSandNotColliding == sandAmount) allowPlayingSandLandingSound = true;
                    }

                    if (platform is Metal) //checks metal
                    {
                        if (distanceBetweenPlayerAnd(platform)) //checks if player is in 1000 pixels distance of a platform, if so it checks that block else it doesn't. this reduces lag
                        {
                            if (platform.TouchPlatform(thePlayer)) metalTemp = true;
                            platform.PlatformEffect(thePlayer, metalTemp);
                        }

                        if (!platform.TouchPlatform(thePlayer)) amountMetalNotColliding++;
                        if (platform.TouchPlatform(thePlayer) && thePlayer.velocity.Y > 0 && allowPlayingMetalLandingSound)
                        {
                            GameEnvironment.AssetManager.PlaySound("Audio/land_metal");
                            allowPlayingMetalLandingSound = false;
                        }
                        if (amountMetalNotColliding == metalAmount) allowPlayingMetalLandingSound = true;
                    }

                    if (platform is Grass) //checks grass
                    {
                        if (!platform.TouchPlatform(thePlayer)) amountGrassNotColliding++;

                        if (platform.TouchPlatform(thePlayer) && thePlayer.velocity.Y > 0 && allowPlayingGrassLandingSound)
                        {
                            GameEnvironment.AssetManager.PlaySound("Audio/land_grass");
                            allowPlayingGrassLandingSound = false;
                        }
                        if (amountGrassNotColliding == grassAmount) allowPlayingGrassLandingSound = true;

                    }

                    if (distanceBetweenPlayerAnd(platform)) //checks if player is in 1000 pixels distance of a platform, if so it checks that block else it doesn't. this reduces lag
                    {
                        if (platform.CollidesWith(thePlayer) && !(platform is Metal)) thePlayer.slippery = false; //checks if there's no collision with metal plaforms

                        platform.platformCollision(thePlayer); //does platforms collision

                    }

                    foreach (EnemyBean anEnemyBean in enemyBeans.Children)
                    {
                        anEnemyBean.BulletCollisionWith(platform); //makes sure a bullet disappears when it hits a platform
                    }
                }


                foreach (EnemyBean anEnemyBean in enemyBeans.Children)
                {
                    anEnemyBean.EnemyBeanEffectOn(thePlayer, position);
                    thePlayer.explosionDone = anEnemyBean.applyKnockback;
                    if (anEnemyBean is ExplosiveBean) EnemyBeanScreenshake(anEnemyBean.applyKnockback, new Vector2(10, 10));
                    if (anEnemyBean is GiantBean) EnemyBeanScreenshake(anEnemyBean.applyKnockback, new Vector2(10, 10));
                }

                foreach (Pickup iPickups in pickupBeans.Children)
                {
                    iPickups.bounce();

                    if (iPickups.CollidesWith(thePlayer))
                    {
                        iPickups.PickupEffect(thePlayer);
                        if (iPickups is KidneyBean) thePlayer.lastPickedBean = 0;
                        if (iPickups is BrownBean) thePlayer.lastPickedBean = 1;
                        if (iPickups is WhiteBean) thePlayer.lastPickedBean = 2;
                        if (iPickups is CoffeeBean) thePlayer.lastPickedBean = 3;
                    }
                }

                if (theToilet.CollidesWith(thePlayer))
                {
                    PlayingState.finalTime = timeText.Text;
                    theToilet.PickupEffect(thePlayer);
                    Reset();
                }

                icons.BuffCheck(thePlayer); //checks if one of the two permanent buffs is active if so it adds them to the icons list

                thePlayer.CameraOffSetFix(position); //makes sure that fillOrb, explodeOrb and the fartParticles get drawn at the right location
                icons.position = -position; //makes sure the icon are drawn on the correct position

                if (thePlayer.fartFillOrb) fartMeter.fartBar.Shade = Color.Gold; //makes the fartBar gold when the permanent fartFill buff is active

                if (divideScrollVelocity == new Vector2(1, 1)) //If the divideScrollVelocity variable, that determines the preview scrolling time, ends the preview scroll, then the timer can start.
                {
                    timeSeconds += gameTime.ElapsedGameTime.TotalSeconds;
                    timeMinutes += gameTime.ElapsedGameTime.TotalMinutes;
                }

                if ((int)timeSeconds == 60) timeSeconds = 0;
        }


        public override void Reset()
        {
            divideScrollVelocity = new Vector2(20, 8.3f);
            position = new Vector2(-(PracticeMap.cols * PracticeMap.tileSize), 0);
            children.Clear();
            thePlatforms.Children.Clear();
            pickupBeans.Children.Clear();
            dirtFillings.Children.Clear();
            enemyBeans.Children.Clear();
            icons.Children.Clear();

            base.Reset();
            background = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background.position = new Vector2(0, -400);
            fartMeter = new FartMeterComplete();
            platformPosition = new Vector2(0, 20);
            timeSeconds = 0;
            timeMinutes = 0;
            background.Scale = 1.9F;
            this.Add(background);
            icons = new Icons();

            metalAmount = 0;
            grassAmount = 0;
            sandAmount = 0;

            for (int c = 0; c < PracticeMap.cols; c++)
            {
                for (int r = 0; r < PracticeMap.rows; r++)
                {
                    int tile = level.getTile(c, r);

                    if (tile != 0)
                    {
                        if (level.practiceMap[tile] == 69) //Player
                        {
                            thePlayer = new Player(new Vector2(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height)); //, SkinSelectState.skinColor);
                        }
                        if (level.practiceMap[tile] == 1) //Dirt without grass on top
                        {
                            thePlatforms.Add(new Platform(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height, spriteUsed[6]));
                        }
                        if (level.practiceMap[tile] == 2) //Dirt with grass on top
                        {
                            thePlatforms.Add(new Grass(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height, spriteUsed[0], thePlayer));
                            grassAmount++;
                        }
                        if (level.practiceMap[tile] == 3) //Movement sign
                        {
                            this.Add(new MovementSign(new Vector2(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height)));
                        }
                        if (level.practiceMap[tile] == 4) //Spacebar sign
                        {
                            this.Add(new SpaceBarSign(new Vector2(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height)));
                        }
                        if (level.practiceMap[tile] == 5) //Look around sign
                        {
                            this.Add(new LookAroundSign(new Vector2(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height)));
                        }
                        if (level.practiceMap[tile] == 7) //Metal
                        {
                            thePlatforms.Add(new Metal(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height, spriteUsed[0]));
                            metalAmount++;
                        }
                        if (level.practiceMap[tile] == 66) //Tundra
                        {
                            thePlatforms.Add(new Tundra(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height, spriteUsed[0]));
                        }
                        if (level.practiceMap[tile] == 67) //Sand
                        {
                            thePlatforms.Add(new Sand(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height, spriteUsed[0]));
                            sandAmount++;
                        }
                        if (level.practiceMap[tile] == 8) //KidneyBean
                        {
                            pickupBeans.Add(new KidneyBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 9) //BrownBean
                        {
                            pickupBeans.Add(new BrownBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 10) //Enemy ExplosiveBean
                        {
                            enemyBeans.Add(new ExplosiveBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 11) //ClericBean
                        {
                            enemyBeans.Add(new ClericBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 12) //White Beans
                        {
                            pickupBeans.Add(new WhiteBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 13) //SniperBean
                        {
                            enemyBeans.Add(new SniperBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 14) //Giant Bean
                        {
                            enemyBeans.Add(new GiantBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 15) //CoffeeBean
                        {
                            pickupBeans.Add(new CoffeeBean(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 16) // Victory Toilet
                        {
                            theToilet = (new PracticeToilet(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height));
                        }
                        if (level.practiceMap[tile] == 88) //DirtFill
                        {
                            dirtFillings.Add(new DirtFill(new Vector2(platformPosition.X + c * Platform.width, platformPosition.Y + r * Platform.height)));
                        }
                    }
                }
            }

            this.Add(thePlatforms);
            this.Add(dirtFillings);
            this.Add(theToilet);
            this.Add(thePlayer);
            this.Add(enemyBeans);
            this.Add(pickupBeans);
            this.Add(fartMeter);
            this.Add(icons);

            timeText = new TextGameObject("Sprites/Font/GameFont");
            timeText.Text = "";
            this.Add(timeText);

            if (thePlayer.fartFillOrb) fartMeter.fartBar.Shade = Color.Gold;

            Player.currentFartFill = 0;

            randomNumber = GameEnvironment.Random.Next(0, 2);
            if (randomNumber == 0) randomMusicName = "GameOn"; //Credit: "Game On" By HeatleyBros (https://www.youtube.com/watch?v=Cu3dBvgcp0Y).
            if (randomNumber == 1) randomMusicName = "Hideout"; //Credit: "8 Bit Hideout" By HeatleyBros (https://www.youtube.com/watch?v=W-3kQA61iHA).
            GameEnvironment.AssetManager.PlayMusic("Audio/8Bit" + randomMusicName + "HeatleyBros");
        }



        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);

            if (inputHelper.AnyKeyPressed && divideScrollVelocity != new Vector2(1, 1)) divideScrollVelocity = new Vector2(1, 1);
            if (inputHelper.KeyPressed(Keys.R)) Reset();
            if (inputHelper.KeyPressed(Keys.Q))
            {
                GameEnvironment.GameStateManager.SwitchTo("TrainingEndState");
                Reset();
            }
        }

        private void EnemyBeanScreenshake(bool applyKnockback, Vector2 screeshakePower)
        {
            if (applyKnockback) //because the explosive bean applyKnockback remains true for random frames it is not possible to check the exact number of frames
            { //the chosen number of frames is 90 because that makes sure that it always finishes the applyknockback before reseting the screenshake
                screenshake = screeshakePower;
                ticks += 0.007f;
                position.X += (float)(Math.Sin(2000 * ticks) * screenshake.X); //shakes from left to right harder then from top to bottom
                position.Y += (float)(Math.Sin(1000 * ticks) * screenshake.Y); //shakes from top to bottom
            }
        }

        private bool distanceBetweenPlayerAnd(Platform thePlatform)
        {
            if (Vector2.Distance(thePlayer.position, thePlatform.position) <= 1000) return true;
            else return false;
        }
    }
}

