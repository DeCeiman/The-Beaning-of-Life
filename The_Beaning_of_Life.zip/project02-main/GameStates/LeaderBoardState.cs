﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class LeaderBoardState : GameObjectList
    {
        private GameObjectList menuButtons = new GameObjectList();
        private SpriteGameObject background;
        private SpriteGameObject gameTitle;
        private SpriteGameObject selectArrow, mouseCursor;
        private int arrowOffset;
        public int buttonSelected;
        private int returnButtonY, returnButtonX;
        public bool buttonIsPressed, clicked;
        
        public LeaderBoardState() : base()
        {
            
            Reset();
            selectArrow.Origin = selectArrow.Center;
            mouseCursor.Origin = mouseCursor.Center;
            gameTitle.position = new Vector2(300, -40);
        }

        public override void Reset()
        {
            base.Reset();
            arrowOffset = 100;
            returnButtonX = 125;
            returnButtonY = 50;

            background = new SpriteGameObject("Sprites/Backgrounds/background_test");
            background.position = new Vector2(0, 0);
            this.Add(background);

            gameTitle = new SpriteGameObject("Sprites/Hud/title");
            gameTitle.position = new Vector2(300, 50);
            this.Add(gameTitle);

            selectArrow = new SpriteGameObject("Sprites/Hud/select_arrow");
            this.Add(selectArrow);

            menuButtons.Add(new ReturnButton(returnButtonX, returnButtonY));
            this.Add(menuButtons);

            mouseCursor = new SpriteGameObject("Sprites/Hud/cursor");
            this.Add(mouseCursor);
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            selectArrow.position.X = returnButtonX + arrowOffset;
            if (buttonSelected == 0) selectArrow.position = new Vector2(-1000, 0);

            if (buttonSelected == 1)
            {
                selectArrow.position.Y = returnButtonY;
                selectArrow.position.X = returnButtonX+ arrowOffset;
                if (buttonIsPressed) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
            }

            foreach (Button button in menuButtons.Children)
            {
                if (button is ReturnButton)
                {
                    if (mouseCursor.CollidesWith(button) && clicked) GameEnvironment.GameStateManager.SwitchTo("MainMenuState");
                }
            }
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (inputHelper.KeyPressed(Keys.Up)) buttonSelected = 1;
            if (inputHelper.KeyPressed(Keys.Enter)) buttonIsPressed = true;
            else buttonIsPressed = false;

            if (inputHelper.MouseLeftButtonPressed()) clicked = true;
            else clicked = false;
            mouseCursor.position = inputHelper.MousePosition;
        }
    }
}
