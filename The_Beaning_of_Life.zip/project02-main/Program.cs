﻿using System;

namespace BaseProject
{
    public static class Program
    {
        static BeaningOfLife game;

        [STAThread]
        static void Main()
        {
            using (game = new BeaningOfLife())
            game.Run();
        }

        public static void Quit()
        {
            game.Exit();
        }
    }
}