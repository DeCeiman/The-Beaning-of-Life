﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace BaseProject
{
    class ParticleSystem : GameObject
    {
        #region Constants
        public const int AlphaBlendDrawOrder = 100;
        public const int AdditiveBlendDrawOrder = 200;
        #endregion

        #region static fields
        //protected static SpriteBatch spriteBatch;
        public SpriteSheet texture1;
        public SpriteSheet texture2;
        public SpriteSheet texture3;
        //protected static ContentManager contentManager;
        #endregion

        #region private fields
        Particle[] particles;
        Queue<int> freeParticles;
        #endregion

        #region protected fields
        protected BlendState blendState = BlendState.AlphaBlend;
        //protected string TextureFilename;
        protected int minNumParticles;
        protected int maxNumParticles;
        #endregion

        #region public properties
        public int FreeParticleCount => freeParticles.Count;
        #endregion


        public ParticleSystem(int MaxParticles)
        {
            texture1 = new SpriteSheet("Sprites/Orbs/fartExplodeOrb");
            texture2 = new SpriteSheet("Sprites/Beans/BrownBean");
            texture3 = new SpriteSheet("Sprites/Beans/WhiteBean");
            particles = new Particle[MaxParticles];
            freeParticles = new Queue<int>(MaxParticles);
            for (int i = 0; i < particles.Length; i++)
            {

                particles[i].Initialize(Vector2.Zero, Vector2.Zero, new Vector2(0, 100), Color.Brown);
                freeParticles.Enqueue(i);
            }
            minNumParticles = 100;
            maxNumParticles = 200;

            //Initialize(Position, Vector2.UnitY * 260, Vector2.Zero, 255, Color.White, 0, 2, 10, lifetime: 3, scale: 12);
        }

        protected virtual void UpdateParticle(ref Particle particle, float dt)
        {
            particle.Velocity += particle.Acceleration * dt;
            particle.Rotation += particle.AngularVelocity * dt;
            particle.Position += particle.Velocity * dt;
            particle.Scale += particle.ScaleIncrease * dt;

            particle.AngularVelocity += particle.AngularAcceleration * dt;
            particle.Rotation += particle.AngularVelocity * dt;

            particle.Opacity -= 2 * dt;

            particle.TimeSinceStart += dt;
        }

        protected virtual void InitializeParticles(ref Particle p, Vector2 position, Vector2 velocity, Vector2 acceleration, float opacity, Color color, float scaleIncrease, int spriteNumber, int totalParticles, float lifetime = 1, float scale = 1, float rotation = 0, float angularVelocity = 0, float angularAcceleration = 0)
        {
            p.Initialize(position, velocity, acceleration, opacity, color, scaleIncrease, spriteNumber, totalParticles, lifetime: 3, scale: 12, rotation: 0, angularVelocity: 0, angularAcceleration: 0);
        }

        public override void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            for (int i = 0; i < particles.Length; i++)
            {
                if (particles[i].Active)
                {
                    UpdateParticle(ref particles[i], dt);

                    if (!particles[i].Active)
                    {
                        freeParticles.Enqueue(i);
                    }
                }
            }

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            foreach (Particle p in particles)
            {
                if (!p.Active)
                    continue;
                if (p.SpriteNumber == 1)
                {
                    texture1.Draw(spriteBatch, p.Position - parent.GlobalPosition, texture1.Center, p.Scale);
                }
                else if (p.SpriteNumber == 2)
                {
                    texture2.Draw(spriteBatch, p.Position - parent.GlobalPosition, texture2.Center, p.Scale);
                }
                else if (p.SpriteNumber == 3)
                {
                    texture3.Draw(spriteBatch, p.Position - parent.GlobalPosition, texture3.Center, p.Scale);
                }
            }
        }

        public void AddParticles(Vector2 position, Vector2 velocity, Vector2 acceleration, float opacity, Color color, float scaleIncrease, int spriteNumber, int totalParticles, float lifetime = 1, float scale = 1, float rotation = 0, float angularVelocity = 0, float angularAcceleration = 0)
        {

            for (int i = 0; i < totalParticles && freeParticles.Count > 0; i++)
            {
                int index = freeParticles.Dequeue();
                InitializeParticles(ref particles[index], position, velocity, acceleration, opacity, color, scaleIncrease, spriteNumber, totalParticles, lifetime = 1, scale = 1, rotation = 0, angularVelocity = 0, angularAcceleration = 0);
            }
        }

    }
}
