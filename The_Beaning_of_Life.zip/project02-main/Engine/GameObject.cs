﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using BaseProject;

public abstract class GameObject : IGameLoopObject
{
    protected GameObject parent;
    public Vector2 position, velocity, PausedVelocity;
    public float gravity,acceleration,friction;
    public float PausedGravity;
    protected int layer;
    protected string id;
    protected bool visible;
    public bool slippery,slow;

    public GameObject(int layer = 0, string id = "")
    {
        this.layer = layer;
        this.id = id;
        position = Vector2.Zero;
        velocity = Vector2.Zero;
        visible = true;
        PausedGravity = 1;
    }

    public virtual void HandleInput(InputHelper inputHelper)
    {
    }

    public virtual void Update(GameTime gameTime)
    {
        if (PlayingState.paused) PausedGravity = 0;
        else PausedGravity = 1;
        velocity.Y += (gravity * (float)gameTime.ElapsedGameTime.TotalSeconds) * PausedGravity;

        position += (velocity * (float)gameTime.ElapsedGameTime.TotalSeconds) * PausedGravity;
    }

    public virtual void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
    }

    public virtual void Reset()
    {
        visible = true;
    }

    public virtual Vector2 Position
    {
        get { return position; }
        set { position = value; }
    }

    public virtual Vector2 Velocity
    {
        get { return velocity; }
        set { velocity = value; }
    }

    public virtual Vector2 GlobalPosition
    {
        get
        {
            if (parent != null)
            {
                return parent.GlobalPosition + Position;
            }
            else
            {
                return Position;
            }
        }
    }

    public GameObject Root
    {
        get
        {
            if (parent != null)
            {
                return parent.Root;
            }
            else
            {
                return this;
            }
        }
    }

    public GameObjectList GameWorld
    {
        get
        {
            return Root as GameObjectList;
        }
    }

    public virtual int Layer
    {
        get { return layer; }
        set { layer = value; }
    }

    public virtual GameObject Parent
    {
        get { return parent; }
        set { parent = value; }
    }

    public string Id
    {
        get { return id; }
    }

    public bool Visible
    {
        get { return visible; }
        set { visible = value; }
    }

    public virtual Rectangle BoundingBox
    {
        get
        {
            return new Rectangle((int)GlobalPosition.X, (int)GlobalPosition.Y, 0, 0);
        }
    }
}