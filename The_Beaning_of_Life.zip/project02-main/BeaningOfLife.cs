﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class BeaningOfLife : GameEnvironment
    {
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();

            screen.X = 1280;
            screen.Y = 720;
            ApplyResolutionSettings();
            
            GameStateManager.AddGameState("MainMenuState", new MainMenuState());
            GameStateManager.AddGameState("PlayingState", new PlayingState());
            GameStateManager.AddGameState("EndGameState", new EndGameState());
            GameStateManager.AddGameState("LeaderBoardState", new LeaderBoardState());
            GameStateManager.AddGameState("SkinSelectState", new SkinSelectState());
            GameStateManager.AddGameState("CreditState", new CreditState());
            GameStateManager.AddGameState("PracticeState", new PracticeState());
            GameStateManager.AddGameState("LoadingState", new LoadingState());
            GameStateManager.AddGameState("TrainingEndState", new TrainingEndState());
            GameStateManager.AddGameState("QuitState", new QuitState());
            GameStateManager.AddGameState("SettingsState", new SettingsState());

            GameStateManager.SwitchTo("LoadingState");
        }
    }
}