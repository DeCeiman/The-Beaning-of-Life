﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class FartMeterComplete : SpriteGameObject
    {
        public SpriteGameObject fartBar = new SpriteGameObject("Sprites/FartMeter/fart_meter");

        private float maxFart;
        private float currentFartFill;
        private float sizeDifferenceBetweenBarAndInside = 4;
        private Vector2 textureSize;
        private float fartDeduction;

        public FartMeterComplete() : base("Sprites/FartMeter/shit_bar")
        {
            fartBar.Origin = fartBar.Center;
            fartBar.position.X = GameEnvironment.Screen.X / 2;
            fartBar.position.Y = 26;
            fartBar.Shade = Color.Black;
            textureSize.Y = 37;
            currentFartFill = Player.currentFartFill;
            maxFart = 100;
            position.X = GameEnvironment.Screen.X / 2 - sprite.Width / 2;
            position.Y = 7.5f;
        }

        override public void Update(GameTime gameTime)
        {
            currentFartFill = Player.currentFartFill;
            fartDeduction = Player.fartDeduction;
            currentFartFill = MathHelper.Clamp(currentFartFill, 0, maxFart);
            textureSize.X = currentFartFill * 2 - sizeDifferenceBetweenBarAndInside;
            position.X = GameEnvironment.Screen.X / 2 - textureSize.X / 2;
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            Rectangle rect = new Rectangle((int)position.X, (int)position.Y, (int)textureSize.X, (int)textureSize.Y);
            spriteBatch.Draw(sprite.Sprite, rect, null, Color.White, 0, Origin, SpriteEffects.None, 0);
            fartBar.Draw(gameTime, spriteBatch);
        }
    }
}