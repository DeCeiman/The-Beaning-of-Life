﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class SettingsButton : Button
    {
        public SettingsButton(float posX, float posY) : base("Sprites/Hud/settings_button")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY;
        }

        public override void ButtonPressed()
        {
            base.ButtonPressed();
            //if (buttonIsPressed) GameStateManager.SwitchTo("SettingsState");
        }
    }
}