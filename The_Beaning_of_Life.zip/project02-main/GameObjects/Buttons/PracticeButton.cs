﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class PracticeButton : Button
    {
        public PracticeButton(float posX, float posY) : base("Sprites/Hud/practice_button")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY;
        }

        public override void ButtonPressed()
        {
            base.ButtonPressed();
            //if (buttonIsPressed) GameStateManager.SwitchTo("PracticeState");
        }
    }
}
