﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
namespace BaseProject
{
    class RestartButton : Button
    {
        public RestartButton(float posX, float posY) : base("Sprites/Hud/restart_button")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY;
        }
    }
}
