﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class CreditsButton : Button
    {
        public CreditsButton(float posX, float posY) : base("Sprites/Hud/credits_button")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY;
        }

        public override void ButtonPressed()
        {
            base.ButtonPressed();
            //if (buttonIsPressed) GameStateManager.SwitchTo("CreditsState");
        }
    }
}
