﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class SelectButton : Button
    {
        public SelectButton(float posX, float posY) : base("Sprites/Hud/select_button")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY;
        }

        public override void ButtonPressed()
        {
            base.ButtonPressed();
            //if (buttonIsPressed) GameStateManager.SwitchTo("MainMenuState") & thePlayer.Color = SkinNumber;
        }
    }
}