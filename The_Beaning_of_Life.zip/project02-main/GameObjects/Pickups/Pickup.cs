﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class Pickup : SpriteGameObject
    {
        public bool pickedUp = false;
        public float pickedUpTimer = 0;
        public Vector2 oldPosition;
        private float timerValue = 420;
        public bool respawning, allowRespawn;
        public float opacity;
        protected float halfBarFill = 50, fullBarFill = 100;
        int ticks;
        public Rectangle rect;

        public Pickup(string Sprites) : base(Sprites)
        {
            Reset();
        }

        public override void Reset()
        {
            position = oldPosition; //reset to old position
            pickedUpTimer = timerValue;
            ticks = GameEnvironment.Random.Next(0, 121);
            base.Reset();
        }

        virtual public void bounce()
        {
            ticks++;
            position.Y += MathF.Sin(ticks * 0.5f * MathF.PI / 25);
        }

        public override void Update(GameTime gameTime)
        {
            if (Player.currentFartFill <= 0) allowRespawn = true;
            else if (!respawning) allowRespawn = false;

            base.Update(gameTime);

            if (pickedUpTimer < timerValue && allowRespawn)
            {
                respawning = true;
                pickedUpTimer = (pickedUpTimer + 1) * PausedGravity;
            }

            if (PlayingState.paused) PausedGravity = 0;
            else PausedGravity = 1;

            opacity = (pickedUpTimer / timerValue) * PausedGravity;
            scale = ((pickedUpTimer / timerValue) / 2) * PausedGravity;
            if (opacity < 255) shade = Color.White * opacity;

            if (pickedUpTimer >= timerValue)
            {
                respawning = false;
                pickedUp = false;
            }
        }

        virtual public void PickupEffect(Player thePlayer)
        {
            if (!pickedUp)
            {
                pickedUp = true;
                pickedUpTimer = 0;
                GameEnvironment.AssetManager.PlaySound("Audio/eating_pick_up_bean");
            }
        }
    }
}