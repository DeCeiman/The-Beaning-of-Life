﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class WhiteBean : Pickup
    {
        public WhiteBean(float positionX, float positionY) : base("Sprites/Beans/white_bean")
        {
            position.X = positionX;
            position.Y = positionY;
            oldPosition.X = position.X; //save initial positionX
            oldPosition.Y = position.Y; //save initial positionY
            size.X = 20;
            size.Y = 35;
            Reset();
        }

        public override void PickupEffect(Player thePlayer)
        {
            if (!pickedUp) thePlayer.fartExplodeOrb = thePlayer.maxExplodeOrb;
            base.PickupEffect(thePlayer);
        }
    }
}