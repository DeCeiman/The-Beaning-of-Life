﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class BrownBean : Pickup
    {
        public BrownBean(float positionX, float positionY) : base("Sprites/Beans/brown_bean")
        {
            position.X = positionX;
            position.Y = positionY;
            oldPosition.X = position.X; //save initial positionX
            oldPosition.Y = position.Y; //save initial positionY
            size.X = 20;
            size.Y = 35;
            Reset();
        }

        public override void PickupEffect(Player thePlayer)
        {
            if (Player.currentFartFill < Player.maxFart)
            {
                if (!pickedUp) Player.currentFartFill += fullBarFill;
                base.PickupEffect(thePlayer);
            }
        }
    }
}