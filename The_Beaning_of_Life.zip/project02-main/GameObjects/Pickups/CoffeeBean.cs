﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class CoffeeBean : Pickup
    {
        private int regularFartDeduction = 2, unlimitedFartTime, unlimitedFartTimer = 120;
        private bool beanEffectDone;

        public CoffeeBean(float positionX, float positionY) : base("Sprites/Beans/coffee_bean")
        {
            position.X = positionX;
            position.Y = positionY;
            oldPosition.X = position.X; //save initial positionX
            oldPosition.Y = position.Y; //save initial positionY
            size.X = 20;
            size.Y = 35;
            Reset();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (beanEffectDone)
            {
                unlimitedFartTime++; //counts how many frames have passed since the effect
                if (unlimitedFartTime >= unlimitedFartTimer) //checks if the effect has been going for 2 seconds
                {
                    Player.fartDeduction = regularFartDeduction; //puts the fart deduction back to normal
                    unlimitedFartTime = 0;
                    beanEffectDone = false;
                }
            }
        }

        public override void PickupEffect(Player thePlayer)
        {
            if (Player.currentFartFill < Player.maxFart)
            {
                if (!pickedUp)
                {
                    Player.currentFartFill += fullBarFill; //fills bar once
                    Player.fartDeduction = 0; //puts the fart deduction on zero so that the player can fart without consequence
                    beanEffectDone = true; //makes sure that the effect can be reversed
                }

                base.PickupEffect(thePlayer);
            }
        }
    }
}