﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class PracticeToilet : Pickup
    {
        public PracticeToilet(float positionX, float positionY) : base("Sprites/Extras/toilet")
        {
            position.X = positionX;
            position.Y = positionY + 40;
            oldPosition.X = position.X; //save initial positionX
            oldPosition.Y = position.Y; //save initial positionY
            Origin = Center;
            Mirror = true;
            Reset();
        }

        public override void PickupEffect(Player thePlayer)
        {
            GameEnvironment.GameStateManager.SwitchTo("TrainingEndState");
        }

        public override void bounce()
        {

        }
    }
}