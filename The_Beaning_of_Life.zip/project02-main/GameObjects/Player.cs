﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class Player : SpriteGameObject
    {
        public static float fartDeduction, currentFartFill, maxFart;
        public float maxVelocityY, minVelocityY, velocityX, slowVelocityX;
        public float fartPower, explosiveFartPower;
        public bool spikyShoes, fartFillOrb, explosionDone, iceGloves;
        private bool facingLeft;
        public int fartExplodeOrb, maxExplodeOrb;
        private int fartRefillTimer, currentState;
        public float fartFillOverTime;
        private int animFrameRight, animFrameLeft;
        public SpriteGameObject fillOrb, explodeOrb;
        public bool newFartFill = true;
        public float regularFartPower = 1800;
        private int fartTimer = 3;
        private int randomFartNumber;
        public bool lookUp = false, lookDown = false, lookLeft = false, lookRight = false;
        public String[] state = { "Sprites/Yellow/alien_yellow", "Sprites/Yellow/alien_yellow_walk1", "Sprites/Yellow/alien_yellow_walk2", "Sprites/Yellow/alien_yellow_hurt" };
        private GameObjectList fartParticles = new GameObjectList();
        public int lastPickedBean;
        //public int playerColor;
        public bool theParticleHadCollisionOnce;
        public Player(Vector2 position) : base("Sprites/Yellow/alien_yellow")
        {
            velocityX = 480;
            slowVelocityX = 240;
            this.position = position;
            origin = Center;
            maxVelocityY = 1000;
            minVelocityY = -1000;
            maxFart = 100;
            fartDeduction = 2;
            fartPower = 1800;
            explosiveFartPower = 70000;
            fartExplodeOrb = 0;
            maxExplodeOrb = 3;
            fillOrb = new SpriteGameObject("Sprites/Orbs/fart_fill_orb");
            explodeOrb = new SpriteGameObject("Sprites/Orbs/fart_explode_orb");

            /*if (color == 0) state.Shade = Color.FromNonPremultiplied(255, 255, 0, 250); //yellow
            if (color == 1) state.Shade = Color.FromNonPremultiplied(0, 0, 255, 250); //blue
            if (color == 2) state.Shade = Color.FromNonPremultiplied(255, 0, 0, 250); //red
            if (color == 3) state.Shade = Color.FromNonPremultiplied(0, 255, 0, 250); //green
            if (color == 4) state.Shade = Color.FromNonPremultiplied(69, 69, 69, 250); //gray
            if (color == 5) state.Shade = Color.FromNonPremultiplied(0, 0, 0, 250); //black
            if (color == 6) state.Shade = Color.FromNonPremultiplied(255, 255, 255, 250); //white
            if (color == 7) hade = Color.FromNonPremultiplied(128, 128, 128, 125); //ghost */
        }

        override public void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            sprite = new SpriteSheet("" + state[currentState] + "");
            if (velocity.X == 0) { currentState = 0; }
            if (Math.Abs(velocity.Y) < 26 && velocity.X > 0)
            {
                facingLeft = false;

                animFrameLeft++;

                if (animFrameLeft > 3)
                {
                    currentState = 1;
                }

                if (animFrameLeft > 6)
                {
                    currentState = 2;
                    animFrameLeft = 0;
                }
            }

            else if (Math.Abs(velocity.Y) < 26 && velocity.X < 0)
            {
                facingLeft = true;
                animFrameRight++;

                if (animFrameRight > 3)
                {
                    currentState = 1;
                }

                if (animFrameRight > 6)
                {
                    currentState = 2;
                    animFrameRight = 0;
                }
            }

            sprite.Mirror = facingLeft;

            if (slippery)
            {
                velocity.X += acceleration * (float)gameTime.ElapsedGameTime.TotalSeconds;
                velocity.X *= friction * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }

            currentFartFill = MathHelper.Clamp(currentFartFill, 0, maxFart);
            position.X = MathHelper.Clamp(position.X, 0, Map.cols * Platform.width - sprite.Width);
            velocity.Y = MathHelper.Clamp(velocity.Y, minVelocityY, maxVelocityY);

            explodeOrb.Update(gameTime);
            FartFillOrb();
            fillOrb.position = new Vector2(position.X - 40, position.Y);
            explodeOrb.position = new Vector2(position.X - 40, position.Y - 20);
            position.Y = (int)Math.Round(position.Y); //stops the bouncing of the player

            fartParticles.Update(gameTime);
            RemoveParticles(30, 5);
        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (inputHelper.IsKeyDown(Keys.Left) && inputHelper.IsKeyDown(Keys.LeftControl)) lookLeft = true;
            else if (inputHelper.IsKeyDown(Keys.Right) && inputHelper.IsKeyDown(Keys.LeftControl)) lookRight = true;
            else if (inputHelper.IsKeyDown(Keys.Up) && inputHelper.IsKeyDown(Keys.LeftControl)) lookUp = true;
            else if (inputHelper.IsKeyDown(Keys.Down) && inputHelper.IsKeyDown(Keys.LeftControl)) lookDown = true;
            else if (slippery)
            {

                if (inputHelper.IsKeyDown(Keys.Left) || inputHelper.IsKeyDown(Keys.A)) { acceleration = -900; friction = 58; }
                else if (inputHelper.IsKeyDown(Keys.Right) || inputHelper.IsKeyDown(Keys.D)) { acceleration = 900; friction = 58; }
                else
                {
                    acceleration = 0;
                    lookUp = false; lookDown = false; lookLeft = false; lookRight = false;
                }
            }

            else if (slow)
            {
                if (inputHelper.IsKeyDown(Keys.Left) || inputHelper.IsKeyDown(Keys.A)) { velocity.X = -slowVelocityX; }
                else if (inputHelper.IsKeyDown(Keys.Right) || inputHelper.IsKeyDown(Keys.D)) { velocity.X = slowVelocityX; }
                else
                {
                    velocity.X = 0;
                    lookUp = false; lookDown = false; lookLeft = false; lookRight = false;
                }

            }

            else if (inputHelper.IsKeyDown(Keys.Left) || inputHelper.IsKeyDown(Keys.A)) { velocity.X = -velocityX; facingLeft = true; }
            else if (inputHelper.IsKeyDown(Keys.Right) || inputHelper.IsKeyDown(Keys.D)) { velocity.X = velocityX; facingLeft = false; }
            else { velocity.X = 0; lookUp = false; lookDown = false; lookLeft = false; lookRight = false; }


            if (inputHelper.IsKeyDown(Keys.Space) && currentFartFill > 0 && fartExplodeOrb <= 0)
            {
                //slippery = false;
                fartTimer += 1;

                if (fartTimer == 4)
                {
                    randomFartNumber = GameEnvironment.Random.Next(1, 14);
                    GameEnvironment.AssetManager.PlaySound("Audio/fart" + randomFartNumber);
                    fartTimer = 0;
                }

                currentState = 3;
                fartParticles.Add(new Farticle(lastPickedBean, new Vector2(position.X, position.Y + Height/2 - 14)));
                currentFartFill -= fartDeduction;
                gravity = -fartPower;
            }

            else if (inputHelper.KeyPressed(Keys.Space) && fartExplodeOrb > 0)
            {
                randomFartNumber = GameEnvironment.Random.Next(1, 4);
                GameEnvironment.AssetManager.PlaySound("Audio/explosive_fart" + randomFartNumber);
                currentState = 3;
                ExplosiveBeanFartParticles(20);

                fartExplodeOrb -= 1;
                gravity = -explosiveFartPower;
            }

            else if (!explosionDone)
            {
                gravity = 1500;
            }

            if (!inputHelper.IsKeyDown(Keys.Space) && fartTimer != 3) fartTimer = 3;
        }

        private void ExplosiveBeanFartParticles(int beanCount)
        {
            for (int i = 0; i <= beanCount; i++)
                fartParticles.Add(new Farticle(lastPickedBean, new Vector2(position.X + Width / 2, position.Y + Height - 9)));
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            fartParticles.Draw(gameTime, spriteBatch);
            base.Draw(gameTime, spriteBatch);

            if (fartExplodeOrb > 0)
            {
                explodeOrb.Draw(gameTime, spriteBatch);
            }
            if (fartFillOrb)
            {
                fillOrb.Draw(gameTime, spriteBatch);
            }
        }

        public void IceGloves() //activates the corresponding buff
        {
            if (iceGloves)
            {
                slippery = false;
            }
        }

        public void FartFillOrb() //activates the corresponding buff
        {
            if (fartFillOrb)
            {
                fartRefillTimer++;

                if (newFartFill)
                {
                    fartFillOverTime += 5; //increases fartfill by 5
                    newFartFill = false;
                }

                if (fartRefillTimer >= 300) //fartRefillTimer grows by 1 every frame once it reaches 300 frames  (5 seconds) it runs the if statement
                {
                    currentFartFill += fartFillOverTime; //fills fartBar every 5 seconds with 5 in the beginning and after that adds another 5 every time fartfill is chosen in the pop up at the cleric bean
                    fartRefillTimer = 0;
                }
            }
        }
        public void CameraOffSetFix(Vector2 cameraOffSet)
        {
            fillOrb.position += cameraOffSet;
            explodeOrb.position += cameraOffSet;
            fartParticles.position = cameraOffSet;
        }
        public void particlesCollideWith(Platform platform)
        {
            if (Vector2.Distance(position, platform.position) < 1000)
            {
                foreach (Farticle theParticle in fartParticles.Children)
                {
                    if (!theParticle.hadCollisionOnce) theParticle.CollisionWith(platform);
                }
            }
        }
        public void RemoveParticles(int maxParticles, int deletionAmountParticles)
        {
            if (fartParticles.Children.Count > maxParticles)
            {
                fartParticles.Children.RemoveRange(0, deletionAmountParticles);
            }
        }
    }
}