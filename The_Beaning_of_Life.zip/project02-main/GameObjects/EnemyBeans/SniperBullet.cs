﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class SniperBullet : RotatingSpriteGameObject
    {
        public bool doKnockBack;
        private Vector2 knockBack;

        public SniperBullet(Vector2 position, Vector2 velocity) : base("Sprites/Bullets/sniper_bean_bullet")
        {
            this.position = position;
            this.velocity = velocity;
            knockBack = this.velocity/6F;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            AngularDirection = -velocity;
        }

        public void bulletEffect(Player thePlayer)
        {
            if (CollidesWith(thePlayer)) {
                Visible = false;
                GameEnvironment.AssetManager.PlaySound("Audio/hit_marker_noise");
                doKnockBack = true;
            }

            if (doKnockBack)
            {
                if (knockBack != Vector2.Zero && knockBack.Length() > 0.1f)
                {
                    knockBack /= 1.1F;
                    thePlayer.position += knockBack;
                }
                
                else doKnockBack = false;
            }
        }
    }
}