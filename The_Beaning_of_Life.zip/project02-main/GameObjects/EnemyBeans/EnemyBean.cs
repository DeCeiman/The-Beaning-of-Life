﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class EnemyBean : SpriteGameObject
    {
        public bool applyKnockback;

        public EnemyBean(string assetName) : base(assetName)
        {

        }
        public virtual void EnemyBeanEffectOn(Player thePlayer, Vector2 position)
        {

        }
        public virtual void BulletCollisionWith(Platform otherObject)
        {

        }
        public virtual void IsDead()
        {

        }
    }
}