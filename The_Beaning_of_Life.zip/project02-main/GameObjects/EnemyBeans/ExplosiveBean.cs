﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    enum ExplosiveBeanState
    {
        Idle, Charging, Exploding
    }

    class ExplosiveBean : EnemyBean
    {
        public ExplosiveBeanState state;
        public SpriteSheet texture1, texture2;
        public float explosiveBeanPlayerActivateDistance = 150;
        public float maxExplosionHitDistance = 225;
        public float textureSizeIncrease;
        public float opacity;
        public bool exploded;
        public Vector2 explosionKnockback;
        public float explosionKnockbackPower = 4000;
        public float maxExplosionKnockbackPower = 75;
        public float knockbackSlowingSpeed = 1.1f;
        private int explodeDuration;
        RotatingSpriteGameObject leftEye = new RotatingSpriteGameObject("Sprites/Beans/explosive_bean_eye");
        RotatingSpriteGameObject rightEye = new RotatingSpriteGameObject("Sprites/Beans/explosive_bean_eye");

        public ExplosiveBean(float positionX, float positionY) : base("Sprites/Beans/explosive_bean_new")
        {
            state = ExplosiveBeanState.Idle;
            position.X = positionX + (Width / 2);
            position.Y = positionY + (Height / 3) + 4;
            texture1 = new SpriteSheet("Sprites/Beans/explosive_bean_new");
            texture2 = new SpriteSheet("Sprites/WeaponsAndProjectiles/laser_red_burst");
            Reset();
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            if (state == ExplosiveBeanState.Idle)
            {
                leftEye.Draw(gameTime, spriteBatch);
                rightEye.Draw(gameTime, spriteBatch);
            }
        }

        override public void Reset()
        {
            sprite = texture1;
            origin = Center;
            state = ExplosiveBeanState.Idle;
            explodeDuration = 30;
            scale = 1;
            shade = Color.White;
            textureSizeIncrease = 0.004f;
            opacity = 1;
            exploded = false;
        }

        override public void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            switch (state)
            {
                case ExplosiveBeanState.Idle:
                    break;
                case ExplosiveBeanState.Charging:
                    ChargeUpdate();
                    break;
                case ExplosiveBeanState.Exploding:
                    ExplodingUpdate();
                    break;
                default:
                    break;
            }
        }

        public override void EnemyBeanEffectOn(Player thePlayer, Vector2 position)
        {
            base.EnemyBeanEffectOn(thePlayer, position);
            leftEye.position = this.position + position - new Vector2(8.7F, 22.25F);
            rightEye.position = this.position + position - new Vector2(-7, 29);
            leftEye.Origin = new Vector2(3.7F, 3.3F);
            rightEye.Origin = new Vector2(4F, 3F);
            Vector2 targetVector = thePlayer.position + position - GlobalPosition;
            leftEye.AngularDirection = -targetVector;
            leftEye.Degrees -= 40;
            Vector2 targetVector1 = thePlayer.position + position - GlobalPosition;
            rightEye.AngularDirection = -targetVector1;
            rightEye.Degrees -= 40;

            if (state == ExplosiveBeanState.Exploding) Knockback(thePlayer); //put Knockback inside of trigger so that I only have to call one method in the playingState
            if (state != ExplosiveBeanState.Exploding && Vector2.Distance(this.position, thePlayer.position) < explosiveBeanPlayerActivateDistance) state = ExplosiveBeanState.Charging;
        }

        private void ChargeUpdate()
        {
            if (state == ExplosiveBeanState.Charging && scale <= 1.2f)
                scale += textureSizeIncrease;

            if (scale > 1.1f)
            {
                GameEnvironment.AssetManager.PlaySound("Audio/explosive_bean_explosion");
                state = ExplosiveBeanState.Exploding;
            }
        }

        public void ExplodingUpdate()
        {
            sprite = texture2;
            origin = Center;
            state = ExplosiveBeanState.Exploding;
            shade = Color.Gold * opacity;

            if (explodeDuration > 0)
            {
                textureSizeIncrease = 0.4f;
                scale += textureSizeIncrease;
                opacity -= 1 / 30.0f;
                explodeDuration--;
            }
        }

        public void Knockback(SpriteGameObject spriteGameObject)
        {
            if (!exploded)
            {
                if (Vector2.Distance(position, spriteGameObject.position) <= maxExplosionHitDistance)
                {
                    explosionKnockback = new Vector2((spriteGameObject.position.X - position.X), (spriteGameObject.position.Y - position.Y));
                    explosionKnockback.Normalize();
                    explosionKnockback = explosionKnockback * (maxExplosionHitDistance - Vector2.Distance(position, spriteGameObject.position));

                    explosionKnockback = new Vector2(MathHelper.Clamp(explosionKnockback.X, -maxExplosionKnockbackPower, maxExplosionKnockbackPower), MathHelper.Clamp(explosionKnockback.Y, -maxExplosionKnockbackPower, maxExplosionKnockbackPower));

                    applyKnockback = true;
                }

                exploded = true;
            }


            if (applyKnockback && (explosionKnockback != Vector2.Zero && explosionKnockback.Length() > 0.1f))
            {
                explosionKnockback /= knockbackSlowingSpeed;
                spriteGameObject.position += explosionKnockback;
            }

            else
            {
                applyKnockback = false;
                if (explodeDuration <= 0) Reset();
            }
        }
    }
}