﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class SniperBean : EnemyBean
    {
        public GameObjectList bullets = new GameObjectList();
        public SpriteGameObject sniperTarget = new SpriteGameObject("Sprites/Targets/sniper_target"), sniper = new SpriteGameObject("Sprites/Beans/sniper_bean_sniper");
        private bool startBulletCountdown, drawTarget, getBulletVelocityOnce = true;
        private int bulletCountdown = 300;
        private Vector2 bulletVelocity, sniperPosition = new Vector2(0, 4.5F);
        private float ticksYAxis = 0, ticksXAxis = 0, barrel = 45;

        public SniperBean(float positionX, float positionY) : base("Sprites/Beans/sniper_bean")
        {
            position.X = positionX - 10;
            position.Y = positionY - 12;
            sniper.Origin = sniper.Center;
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            sniper.Draw(gameTime, spriteBatch);
            bullets.Draw(gameTime, spriteBatch);

            if (drawTarget)
            {
                sniperTarget.Draw(gameTime, spriteBatch);
            }
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            
            foreach (SniperBullet sniperBullet in bullets.Children)
            {
                sniperBullet.Update(gameTime);
            }
        }

        public override void EnemyBeanEffectOn(Player thePlayer, Vector2 cameraPositionFix)
        {
            CollisionHandler(thePlayer); //added here so that only one method is called in the playing state
            base.EnemyBeanEffectOn(thePlayer, position);
            sniper.position = sniperPosition + CenterPosition + cameraPositionFix; // makes sure that the cameraPosition is also added on the sniper position
            
            if (thePlayer.position.X > CenterPosition.X) // if the player is on the right side of the sniperBean it changes to a different sprite
            {
                Mirror = true; //mirrors the sprite
                sniper.Mirror = true;
                sniperPosition.X = 18.5F;
                barrel = 45;
            }

            else if (thePlayer.CenterPosition.X <= CenterPosition.X)
            {
                Mirror = false; //mirrors the sprite
                sniper.Mirror = false;
                sniperPosition.X = -18.5F;
                barrel = -45;
            }

            ticksYAxis += 0.007f;
            sniper.position.Y += (float)(Math.Sin(10 * ticksYAxis) * 1.5F);

            bullets.position = cameraPositionFix;

            if (thePlayer.position.X - position.X <= 750 && thePlayer.position.X - position.X >= -750 && thePlayer.position.Y - position.Y <= 750 && thePlayer.position.Y - position.Y >= -750) //if the player is within a range of 750 pixels then the if statement will be read
            {
                drawTarget = true;
                sniperTarget.position = thePlayer.position - sniperTarget.Center + cameraPositionFix; //adds target onto player

                if (bulletCountdown >= 300) //if bulletcountdown has reached 300 frames then a new bullet will be added
                {
                    GameEnvironment.AssetManager.PlaySound("Audio/sniper_bean_shot");

                    if (getBulletVelocityOnce) //gets distance between player and sniperBean once
                    {
                        bulletVelocity = thePlayer.position - CenterPosition; //get velocity needed to move towards the player
                        getBulletVelocityOnce = false;
                    }

                    bulletVelocity.Normalize(); //normalize the distance so it's the same for each bullet
                    bulletVelocity *= 700; //multiply by 700 to keep the velocity 700
                    bullets.Add(new SniperBullet(CenterPosition + new Vector2(barrel, 3), bulletVelocity)); //make a new bullet at the sniperBean's centerPosition and gives it the velocity from earlier devided by 40 so that it isn't too fast
                    bulletCountdown = 0; //resets the countdown so that the process can start over again
                    startBulletCountdown = true; //starts the countdown
                    getBulletVelocityOnce = true;
                }
            }

            else drawTarget = false;

            if (startBulletCountdown)
            {
                bulletCountdown++;
            }

            if (bulletCountdown <= 60)
            {
                ticksXAxis += 0.01f;
                sniper.position.X += (float)(Math.Sin(10 * ticksXAxis) * 2F);
            }

            foreach (SniperBullet sniperBullet in bullets.Children)
            {
                sniperBullet.bulletEffect(thePlayer);
            }
        }

        public void CollisionHandler(Player thePlayer)
        {
            if (CollidesWith(thePlayer))
            {
                Vector2 depth = Collision.CalculateIntersectionDepth(BoundingBox, thePlayer.BoundingBox);
                Vector2 absoluteDepth = new Vector2(Math.Abs(depth.X), Math.Abs(depth.Y));

                if (depth != Vector2.Zero)
                {
                    if (absoluteDepth.Y > absoluteDepth.X)
                    {
                        thePlayer.velocity.X = 0;
                        depth.Y = 0;
                    }

                    else
                    {
                        thePlayer.velocity.Y = 0;
                        depth.X = 0;
                    }

                    thePlayer.position -= depth;
                }
            }
        }

        public override void BulletCollisionWith(Platform platform)
        {
            foreach (SniperBullet sniperBullet in bullets.Children)
            {
                if (sniperBullet.CollidesWith(platform))
                {
                    sniperBullet.Visible = false;
                }
            }

            base.BulletCollisionWith(platform);
        }
    }
}