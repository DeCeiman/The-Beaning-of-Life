﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class GiantBean : EnemyBean
    {
        private Vector2 knockBack;
        private bool getKnockBackOnce = true, turnBaseballBat;
        RotatingSpriteGameObject giantBeanBat = new RotatingSpriteGameObject("Sprites/Beans/giant_bean_bat");
        RotatingSpriteGameObject giantBeanBatFlipped = new RotatingSpriteGameObject("Sprites/Beans/giant_bean_bat_flipped");

        public GiantBean(float posX, float posY) : base("Sprites/Beans/giant_bean")
        {
            Origin = Center;
            position.X = posX;
            position.Y = posY + 5;
            knockBack.X = -200;
            knockBack.Y = -200;
            Reset();
        }

        public override void Reset()
        {
            base.Reset();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (!Mirror)
            {
                if (turnBaseballBat) giantBeanBat.Degrees -= 13;
                else giantBeanBat.Degrees += 13;
                if (giantBeanBat.Degrees <= -120) turnBaseballBat = false;
                giantBeanBat.Degrees = Math.Clamp(giantBeanBat.Degrees, -120, 0);
            }
            else
            {
                if (turnBaseballBat) giantBeanBatFlipped.Degrees += 13;
                else giantBeanBatFlipped.Degrees -= 13;
                if (giantBeanBatFlipped.Degrees >= 120) turnBaseballBat = false;
                giantBeanBatFlipped.Degrees = Math.Clamp(giantBeanBatFlipped.Degrees, 0, 120);
            }
        }

        public override void EnemyBeanEffectOn(Player thePlayer, Vector2 position)
        {
            base.EnemyBeanEffectOn(thePlayer, position);

            giantBeanBat.position = this.position + position + new Vector2(0, 22.25F);
            giantBeanBat.Origin = new Vector2(0, giantBeanBat.Height);
            giantBeanBatFlipped.position = this.position + position + new Vector2(0, 22.25F);
            giantBeanBatFlipped.Origin = new Vector2(giantBeanBatFlipped.Width, giantBeanBatFlipped.Height);
            if (thePlayer.position.X > CenterPosition.X) // if the player is on the right side of the giantbean it mirrors the sprite
            {
                Mirror = true; //mirrors the sprite
            }

            else if (thePlayer.CenterPosition.X <= CenterPosition.X)
            {
                Mirror = false; //mirrors the sprite
            }

            if (CollidesWith(thePlayer))
            {
                turnBaseballBat = true;
                applyKnockback = true;
                GameEnvironment.AssetManager.PlaySound("Audio/slap_noise");


                if (getKnockBackOnce) //gets distance between player and sniperBean once
                {
                    knockBack = thePlayer.position - CenterPosition; //get velocity needed to move towards the player
                    getKnockBackOnce = false;
                }

                knockBack.Normalize(); //normalize the distance so it's the same for each bullet
                knockBack *= 100; //multiply by 100 to keep the velocity 100
                getKnockBackOnce = true;
            }

            if (applyKnockback)
            {
                if ((knockBack != Vector2.Zero && knockBack.Length() > 0.1f))
                {
                    knockBack /= 1.1F;
                    thePlayer.position += knockBack;
                }

                else applyKnockback = false;
            }
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            if (!Mirror) giantBeanBat.Draw(gameTime, spriteBatch);
            else giantBeanBatFlipped.Draw(gameTime, spriteBatch);
        }
    }
}