﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class ClericBean : EnemyBean
    {
        private int clericBeanBuffCooldown = 600, buffReset = 120, fullFartBar = 100, regularFartDeduction = 2, clericBeanBuffCountdown;
        private bool buffGiven, drawPopUp, onePressed, twoPressed, threePressed, fourPressed;
        SpriteGameObject popUp = new SpriteGameObject("Sprites/Extras/pop_up_cleric_bean"), clericBeanStaff;
        GameObjectList alreadyUsed = new GameObjectList();
        SpriteGameObject[] lockedSprites = new SpriteGameObject[4];
        private bool addOnceIceGloves = true, addOnceSpikyShoes = true, addOnceFartFillOrb = true, lightStaff, resetOnce = true;
        RotatingSpriteGameObject clericBeanStaffLight;
        private Vector2 lighStaffPositionFix = new Vector2(-42.5F, -118.5F), staffPositionFix = new Vector2(3.5F, -41.5F), staffBounce;
        float ticksYAxis;
        private int soundTimer = 359;
        private int randomSoundNumber;

        public ClericBean(float positionX, float positionY) : base("Sprites/Beans/cleric_bean")
        {
            Origin = Center;
            clericBeanStaffLight = new RotatingSpriteGameObject("Sprites/Beans/cleric_bean_staff_light");
            clericBeanStaff = new SpriteGameObject("Sprites/Beans/cleric_bean_staff");
            position.X = positionX;
            position.Y = positionY + 11;

            for (int i = 0; i < 4; i++)
            {
                lockedSprites[i] = new SpriteGameObject("Sprites/Extras/locked");
                lockedSprites[i].position = new Vector2(0, i * 50);
                lockedSprites[i].Scale = 0.8F;
            }
        }

        public void ChangeSprite(int i) //change the sprite when the cleric bean uses ability
        {
            if (i == 1)
            {
                lightStaff = true;
            }

            else lightStaff = false;
        }

        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            base.Draw(gameTime, spriteBatch);
            if (lightStaff) clericBeanStaffLight.Draw(gameTime, spriteBatch);
            else clericBeanStaff.Draw(gameTime, spriteBatch);

            if (drawPopUp)
            {
                popUp.Draw(gameTime, spriteBatch);
                alreadyUsed.Draw(gameTime, spriteBatch);
            }
        }

        public void RandomBuff(Player thePlayer) //start the ability process
        {
            if (position.X - thePlayer.position.X >= -250 && position.X - thePlayer.position.X <= 250 && position.Y - thePlayer.position.Y >= -250 && position.Y - thePlayer.position.Y <= 250 && !buffGiven)
            {
                drawPopUp = true;
                ChangeSprite(1);
            }

            else
            {
                drawPopUp = false;
                ChangeSprite(2);
            }

            if (buffGiven)
            {
                clericBeanBuffCountdown++;
                drawPopUp = false;
                ChangeSprite(2);
            }

            if (clericBeanBuffCountdown >= clericBeanBuffCooldown)
            {
                clericBeanBuffCountdown = 0;
            }

        }

        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);
            if (inputHelper.KeyPressed(Keys.D1)) onePressed = true;
            else onePressed = false;
            if (inputHelper.KeyPressed(Keys.D2)) twoPressed = true;
            else twoPressed = false;
            if (inputHelper.KeyPressed(Keys.D3)) threePressed = true;
            else threePressed = false;
            if (inputHelper.KeyPressed(Keys.D4)) fourPressed = true;
            else fourPressed = false;
        }

        public void BuffLocked(Player thePlayer)
        {
            if (thePlayer.iceGloves && addOnceIceGloves)
            {
                alreadyUsed.Add(lockedSprites[1]);
                addOnceIceGloves = false;
            }

            if (thePlayer.spikyShoes && addOnceSpikyShoes)
            {
                alreadyUsed.Add(lockedSprites[2]);
                addOnceSpikyShoes = false;
            }

            if (thePlayer.fartFillOverTime >= 25 && addOnceFartFillOrb)
            {
                alreadyUsed.Add(lockedSprites[3]);
                addOnceFartFillOrb = false;
            }
        }


        public override void EnemyBeanEffectOn(Player thePlayer, Vector2 cameraOffset)
        {
            ticksYAxis += 0.007f;
            staffBounce = new Vector2(0, (float)(Math.Sin(10 * ticksYAxis) * 1.2F));
            base.EnemyBeanEffectOn(thePlayer, cameraOffset);
            BuffLocked(thePlayer);
            popUp.position = position + cameraOffset - new Vector2(295, 245); //gets accurate position which doesn't move with the camera
            clericBeanStaff.position = (position + cameraOffset + staffPositionFix) + staffBounce;
            clericBeanStaffLight.position = (position + cameraOffset + lighStaffPositionFix) + staffBounce;
            alreadyUsed.position = popUp.position + new Vector2(247, 45);
            RandomBuff(thePlayer);

            if (drawPopUp)
            {
                if (onePressed) //if one is pressed then fill the bar and make the farts not take any charge when used
                {
                    buffGiven = true;
                    Player.currentFartFill = fullFartBar;
                    Player.fartDeduction = 0;
                    GameEnvironment.AssetManager.PlaySound("Audio/cleric_complete");
                }

                if (twoPressed && !thePlayer.iceGloves) //if two is pressed activate iceGloves which makes tundra platforms disappear slower
                {
                    buffGiven = true;
                    thePlayer.iceGloves = true; //if two is pressed then activate iceGloves which is permanent
                    GameEnvironment.AssetManager.PlaySound("Audio/cleric_complete");
                }

                if (threePressed && !thePlayer.spikyShoes) //if three is pressed activate spikyShoes which makes metal platforms not slippery
                {
                    buffGiven = true;
                    thePlayer.spikyShoes = true; //if three is pressed then activate spikyShoes which is permanent
                    GameEnvironment.AssetManager.PlaySound("Audio/cleric_complete");
                }

                if (fourPressed && addOnceFartFillOrb) //if four is pressed then activate fartFillOrb which adds 5 fart charge every 5 seconds
                {
                    buffGiven = true;
                    thePlayer.newFartFill = true;
                    thePlayer.fartFillOrb = true; //if four is pressed then activate fartFillOrb which is permanent. Every time this option is chosen the fartfill adds more
                    GameEnvironment.AssetManager.PlaySound("Audio/cleric_complete");
                }
            }

            if (clericBeanBuffCountdown >= buffReset && resetOnce) //checks if the time passed since the buff is longer than the maximum and if that is the case it reverses the effects
            {
                Player.fartDeduction = regularFartDeduction;
                resetOnce = false;
            }

            if (Vector2.Distance(thePlayer.position, position) <= 600 && !buffGiven)
            {
                soundTimer += 1;

                if (soundTimer == 360)
                {
                    if (!drawPopUp)
                    {
                        randomSoundNumber = GameEnvironment.Random.Next(1, 3);
                        GameEnvironment.AssetManager.PlaySound("Audio/cleric_greet" + randomSoundNumber);
                        soundTimer = 0;
                    }

                    if (drawPopUp)
                    {
                        GameEnvironment.AssetManager.PlaySound("Audio/cleric_negotiate");
                        soundTimer = 0;
                    }
                }
            }

            else if (soundTimer != 359 && !buffGiven)
            {
                GameEnvironment.AssetManager.PlaySound("Audio/cleric_cancel");
                soundTimer = 359;
            }
        }
    }
}