﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class Farticle : SpriteGameObject
    {
        public bool hadCollisionOnce;
        public Farticle(int color, Vector2 startPoint) : base("Sprites/Extras/white_fart_particle")
        {
            origin = Center;
            position = startPoint;
            position.X += GameEnvironment.Random.Next(-15, 15);
            velocity = new Vector2(GameEnvironment.Random.Next(-150, 150), GameEnvironment.Random.Next(200, 300));
            if (color == 0) shade = Color.FromNonPremultiplied(170, 0, 0, 250); //kidneyBean color
            if (color == 1) shade = Color.FromNonPremultiplied(84, 45, 36, 250); //brownBean color
            if (color == 2) shade = Color.FromNonPremultiplied(248, 217, 170, 250); //whiteBean color
            if (color == 3) shade = Color.FromNonPremultiplied(136, 109, 87, 250); //coffeeBean color
        }
        public void CollisionWith(Platform thePlatform)
        {
            if (CollidesWith(thePlatform))
            {
                velocity = Vector2.Zero;
                hadCollisionOnce = true;
            }
        }
    }
}
