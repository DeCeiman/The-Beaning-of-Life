﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class MovementSign : SpriteGameObject
    {
        public MovementSign(Vector2 position) : base("Sprites/Extras/movement_sign")
        {
            origin = Center;
            this.position = position + new Vector2(0, 13);
        }
    }
}
