﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class SpaceBarSign : SpriteGameObject
    {
       public SpaceBarSign(Vector2 position) : base("Sprites/Extras/space_bar_sign")
        {
            origin = Center;
            this.position = position + new Vector2(0, 14);
        }
    }
}
