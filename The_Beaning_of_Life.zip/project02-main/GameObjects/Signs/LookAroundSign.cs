﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class LookAroundSign : SpriteGameObject
    {
        public LookAroundSign(Vector2 position) : base("Sprites/Extras/look_around_sign")
        {
            origin = Center;
            this.position = position + new Vector2(0, 13);
        }
    }
}
