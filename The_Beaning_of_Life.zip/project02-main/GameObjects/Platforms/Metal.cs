﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class Metal : Platform
    {
        public Metal(float xPosPlatform, float yPosPlatform, int used) : base(0, 0, 6)
        {
            position.X = xPosPlatform;
            position.Y = yPosPlatform;
        }

        public override void PlatformEffect(Player thePlayer,bool platformTemp)
        {
            if (!TouchPlatform(thePlayer)) thePlayer.slippery = false;
            if (platformTemp && !thePlayer.spikyShoes) thePlayer.slippery = true;
        }
    }
}