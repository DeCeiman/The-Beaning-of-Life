﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{

    class Sand : Platform
    {
        public Sand(float xPosPlatform, float yPosPlatform, int used) : base(0, 0, 2)
        {
            position.X = xPosPlatform;
            position.Y = yPosPlatform;
        }
        public override void PlatformEffect(Player thePlayer, bool platformTemp)
        {
            if (!TouchPlatform(thePlayer)) thePlayer.slow = false;
            if (platformTemp) thePlayer.slow = true;
        }
    }
}
