﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    class Platform : SpriteGameObject
    {
        //Sprite 0 = Dirt without grass on top
        //Sprite 1 = Dirt with grass on top
        //Sprite 2 = Grass hill which goes to the left
        //Sprite 3 = Grass hill which goes to the right
        //Sprite 4 = Grass corner piece to the right
        //Sprite 5 = Grass corner piece to the left
        //Sprite 6 = Metal block
        //Sprite 7 = Tundra block

        public String[] sprites = { "Sprites/PNGGrass/slice33_33", "Sprites/PNGGrass/slice03_03", "Sprites/PNGSand/slice03_03", "Sprites/PNGGrass/slice07_07", "Sprites/PNGGrass/slice17_17", "Sprites/PNGGrass/slice18_18", "Sprites/PNGMetal/frozen_metal", "Sprites/PNGTundra/slice03_03" };
        public const int height = 70;
        public const int width = 70;

        public Platform(float xPosPlatfrom, float yPosPlatform, int used) : base("", 0, "", 0)
        {
            position.X = xPosPlatfrom;
            position.Y = yPosPlatform;
            sprite = new SpriteSheet("" + sprites[used] + "");
        }

        public void platformCollision(SpriteGameObject entity)
        {
            if (CollidesWith(entity))
            {
                Vector2 depth = Collision.CalculateIntersectionDepth(BoundingBox, entity.BoundingBox);
                Vector2 absoluteDepth = new Vector2(Math.Abs(depth.X), Math.Abs(depth.Y));

                if (depth != Vector2.Zero)
                {
                    if (absoluteDepth.Y > absoluteDepth.X)
                    {
                        entity.velocity.X = 0;
                        depth.Y = 0;
                    }

                    else
                    {
                        entity.velocity.Y = 0;
                        depth.X = 0;
                    }

                    entity.position -= depth;
                }
            }
        }

        public virtual bool TouchPlatform(Player player)
        {
            if (player.BoundingBox.Bottom < BoundingBox.Top + 10 && player.BoundingBox.Bottom > BoundingBox.Top - 10 && player.BoundingBox.Right > BoundingBox.Left && player.BoundingBox.Left < BoundingBox.Right) return true;
            else return false;
        }

        public virtual void PlatformEffect(Player thePlayer, bool platformTemp = false)
        {
        }
    }
}
