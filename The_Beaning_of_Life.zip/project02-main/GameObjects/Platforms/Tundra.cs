﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class Tundra : Platform
    {
        int currentState = 4;
        private int state1 = 30, state2 = 60;
        private int disapearTimer = 150;
        private int startTimer = 0;
        private int reapearTimer = 450;
        public bool TundraEffectStatus;
        public String[] state = { "Sprites/PNGTundra/tundra_break_state1", "Sprites/PNGTundra/tundra_break_state2", "Sprites/PNGTundra/tundra_break_state3", "Sprites/PNGTundra/tundra_break_state4", "Sprites/PNGTundra/slice03_03" };
        public Tundra(float xPosMetal, float yPosPlatform, int used) : base(0, 0, 7)
        {
            currentState = 4;
            position.X = xPosMetal;
            position.Y = yPosPlatform;

        }

        public void TundraEffect(Player thePlayer)
        {
            sprite = new SpriteSheet("" + state[currentState] + "");
            if (thePlayer.iceGloves)
            {
                
                disapearTimer = 300;


            }
            if (TundraEffectStatus == true && thePlayer.iceGloves) 
            {
                startTimer++;

                if (startTimer >= 60) { currentState = 0; }
                if (startTimer >= 120) { currentState = 1; }
                if (startTimer >= 180) { currentState = 2; }
                if (startTimer >= 240) { currentState = 3; }
                if (startTimer >= disapearTimer)
                {

                    visible = false;
                }

            }
            else if (TundraEffectStatus == true)
            {
                startTimer++;
                //use 4 sprites to show breakage

                if (startTimer >= state1 && startTimer < state2) { currentState = 0; }
                if (startTimer >= 60) { currentState = 1; }
                if (startTimer >= 90) { currentState = 2; }
                if (startTimer >= 120) { currentState = 3; }
                if (startTimer >= disapearTimer)
                {

                    visible = false;
                }
                if (startTimer >= reapearTimer)
                {
                    currentState = 4;
                    visible = true;
                    startTimer = 0;
                    TundraEffectStatus = false;
                }

            }
        }
        public override bool TouchPlatform(Player player)
        {
            if (CollidesWith(player)) return true;
            else return false;
        }

        public override void PlatformEffect(Player thePlayer, bool platformTemp)
        {
            if (CollidesWith(thePlayer))
            {
                TundraEffectStatus = true;
            }

            TundraEffect(thePlayer);
        }
    }
}
