﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace BaseProject
{
    
    class Tile : Platform
    {
        
        public enum TyleType
        {
        //Metal
        //return 1 if tyletype is metal
        Metal = 1,
        //Slow
        //return 2 if tyletype is slow
        Slow = 2,
        //Snow/Ice
        //return 3 if tyletype is snow/ice
        temporary = 3,
        //bounce
        //return 3 if tyletype is bouncy
        bounce = 4,


        }


        public Tile() : base(0,0,0) { }
        public void slippery(SpriteGameObject entity) 
        {
               //Check if entity colides with platfrom
            
                //Add the slippery effect
                entity.acceleration = 1;
                entity.friction = 0.1f;
                
            
        }
        private void Slow(SpriteGameObject entity) 
        {
            //Check if entity colides with platfrom
            if (CollidesWith(entity)) 
            {
                //Add Slow effect
            }
        }
        private void Temporary(SpriteGameObject entity) 
        {
            //Check if entity colides with platfrom
            if (CollidesWith(entity)) 
            { 
                //Add Temporary platfrom effect
            }
        }
        private void Bounce(SpriteGameObject entity) 
        {
            //Check if entity colides with platfrom
            if (CollidesWith(entity)) 
            { 
                //Add bounce effect
            }
        }



    }
}
