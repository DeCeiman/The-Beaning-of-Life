﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class Grass : Platform
    {
        public Grass(float xPosPlatform, float yPosPlatform, int used, Player player) : base(0, 0, 1)
        {
            position.X = xPosPlatform;
            position.Y = yPosPlatform;
        }
    }
}
