﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class DirtFill : SpriteGameObject
    {
        public DirtFill(Vector2 position) : base("Sprites/Dirt/dirt_filling")
        {
            this.position = position;
        }
    }
}