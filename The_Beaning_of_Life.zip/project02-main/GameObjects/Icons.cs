﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BaseProject
{
    class Icons : GameObjectList
    {
        SpriteGameObject spikyShoesIcon;
        SpriteGameObject iceGloves;
        bool checkOnceGloves = true, checkOnceSpiky = true;
        TextGameObject resetText;
        public Icons()
        {
            spikyShoesIcon = new SpriteGameObject("Sprites/Extras/spiky_shoes");
            iceGloves = new SpriteGameObject("Sprites/Extras/ice_gloves_icon");
            resetText = new TextGameObject("Sprites/Font/GameFont");

            spikyShoesIcon.position = new Vector2(GameEnvironment.Screen.X - spikyShoesIcon.Width - 10, spikyShoesIcon.Height * 1.5F);
            iceGloves.position = new Vector2(GameEnvironment.Screen.X - spikyShoesIcon.Width - iceGloves.Width - 15, spikyShoesIcon.Height * 1.5F);

            resetText.Color = Color.Black;
            resetText.Text = "R to reset";
            resetText.position = new Vector2(GameEnvironment.Screen.X - resetText.Size.X - 15, 0);
            this.Add(resetText);
        }

        public void BuffCheck(Player thePlayer)
        {
            if (thePlayer.spikyShoes && checkOnceSpiky)
            {
                this.Add(spikyShoesIcon);
                checkOnceSpiky = false;
            }

            if (thePlayer.iceGloves && checkOnceGloves)
            {
                this.Add(iceGloves);
                checkOnceGloves = false;
            }

            if(thePlayer.position.Y <= 6000) resetText.Color = Color.White;
        }
    }
}